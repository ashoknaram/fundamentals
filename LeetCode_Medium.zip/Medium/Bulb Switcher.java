class Solution {
  public int bulbSwitch(int n) {
    return (int) Math.sqrt(n);
  }
}
